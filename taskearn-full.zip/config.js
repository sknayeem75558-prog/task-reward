// তোমার নিজের Supabase তথ্য এখানে বসাও। service_role/secret key ব্যবহার করবে না।
const SUPABASE_URL = "PASTE_YOUR_SUPABASE_URL";
const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_KEY";
const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);